/*!
* Start Bootstrap - Grayscale v7.0.6 (https://startbootstrap.com/theme/grayscale)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-grayscale/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Shrink the navbar 
    navbarShrink();

    // Shrink the navbar when page is scrolled
    document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            rootMargin: '0px 0px -40%',
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

    // Initialize Carousel
    initCarousel();

});

// Carousel functionality
function initCarousel() {
    const carouselSlides = document.querySelectorAll('.carousel-slide');
    const carouselDots = document.querySelectorAll('.carousel-dot');
    const nextBtn = document.getElementById('next-slide');
    const prevBtn = document.getElementById('prev-slide');
    
    console.log('Carousel initialization:', {
        slides: carouselSlides.length,
        dots: carouselDots.length,
        nextBtn: !!nextBtn,
        prevBtn: !!prevBtn
    });
    
    if (!carouselSlides.length || !nextBtn || !prevBtn) {
        console.error('Carousel elements not found');
        return; // Exit if carousel elements don't exist
    }
    
    let currentSlide = 0;
    const totalSlides = carouselSlides.length;
    
    console.log(`Carousel initialized with ${totalSlides} slides`);
    
    // Update total slides count in status indicator
    const totalSlidesSpan = document.getElementById('total-slides');
    if (totalSlidesSpan) {
        totalSlidesSpan.textContent = totalSlides;
    }
    
    // Initialize first slide
    showSlide(0);
    
    function showSlide(index) {
        console.log(`Showing slide ${index}`);
        carouselSlides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
        carouselDots.forEach((dot, i) => {
            dot.classList.toggle('active', i === index);
        });
        currentSlide = index;
        
        // Update status indicator
        const currentSlideSpan = document.getElementById('current-slide');
        if (currentSlideSpan) {
            currentSlideSpan.textContent = `Slide ${index + 1}`;
        }
    }

    function nextSlide() {
        const next = (currentSlide + 1) % totalSlides;
        console.log(`Next slide: ${next}`);
        showSlide(next);
    }

    function prevSlide() {
        const prev = (currentSlide - 1 + totalSlides) % totalSlides;
        console.log(`Previous slide: ${prev}`);
        showSlide(prev);
    }

    // Auto-advance carousel
    let carouselInterval = setInterval(nextSlide, 5000);

    // Carousel event listeners
    nextBtn.addEventListener('click', () => {
        console.log('Next button clicked');
        nextSlide();
        clearInterval(carouselInterval);
        carouselInterval = setInterval(nextSlide, 5000);
    });

    prevBtn.addEventListener('click', () => {
        console.log('Previous button clicked');
        prevSlide();
        clearInterval(carouselInterval);
        carouselInterval = setInterval(nextSlide, 5000);
    });

    carouselDots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            console.log(`Dot ${index} clicked`);
            showSlide(index);
            clearInterval(carouselInterval);
            carouselInterval = setInterval(nextSlide, 5000);
        });
    });

    // Pause carousel on hover
    const carouselContainer = document.querySelector('.carousel-container');
    if (carouselContainer) {
        carouselContainer.addEventListener('mouseenter', () => {
            console.log('Carousel paused on hover');
            clearInterval(carouselInterval);
        });

        carouselContainer.addEventListener('mouseleave', () => {
            console.log('Carousel resumed');
            carouselInterval = setInterval(nextSlide, 5000);
        });
    }
    
    // Add keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            clearInterval(carouselInterval);
            carouselInterval = setInterval(nextSlide, 5000);
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            clearInterval(carouselInterval);
            carouselInterval = setInterval(nextSlide, 5000);
        }
    });
}
